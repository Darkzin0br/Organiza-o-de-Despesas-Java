import model.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static DespesaService despesaService = new DespesaService();
    private static UsuarioService usuarioService = new UsuarioService();
    private static TipoDespesaService tipoDespesaService = new TipoDespesaService();
    private static Scanner scanner = new Scanner(System.in);
    private static String usuarioLogado = "admin";
    
    public static void main(String[] args) {
        inicializarSistema();
        exibirMenuPrincipal();
    }
    
    private static void inicializarSistema() {
        // Criar usuário admin padrão se não existir
        if (usuarioService.buscarUsuarioPorLogin("admin") == null) {
            usuarioService.cadastrarUsuario("admin", "admin123", "Administrador");
        }
        
        // Criar alguns tipos de despesa padrão
        if (tipoDespesaService.listarTiposDespesa().isEmpty()) {
            tipoDespesaService.criarTipoDespesa("Aluguel", "Pagamento de aluguel");
            tipoDespesaService.criarTipoDespesa("Supermercado", "Compras do mês");
            tipoDespesaService.criarTipoDespesa("Transporte", "Passagem/Combustível");
            tipoDespesaService.criarTipoDespesa("Lazer", "Cinema/Restaurante");
        }
        
        System.out.println("Sistema inicializado com sucesso!");
    }
    
    private static void exibirMenuPrincipal() {
        while (true) {
            System.out.println("\n=== SISTEMA DE CONTROLE DE DESPESAS ===");
            System.out.println("1. Entrar Despesa");
            System.out.println("2. Anotar Pagamento");
            System.out.println("3. Listar Despesas em Aberto");
            System.out.println("4. Listar Despesas Pagas");
            System.out.println("5. Gerenciar Tipos de Despesa");
            System.out.println("6. Gerenciar Usuários");
            System.out.println("7. Sair");
            System.out.print("Escolha uma opção: ");
            
            int opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1:
                    entrarDespesa();
                    break;
                case 2:
                    anotarPagamento();
                    break;
                case 3:
                    listarDespesasEmAberto();
                    break;
                case 4:
                    listarDespesasPagas();
                    break;
                case 5:
                    gerenciarTiposDespesa();
                    break;
                case 6:
                    gerenciarUsuarios();
                    break;
                case 7:
                    System.out.println("Saindo do sistema...");
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }
    
    private static void entrarDespesa() {
        System.out.println("\n=== ENTRAR DESPESA ===");
        
        System.out.print("Descrição: ");
        String descricao = scanner.nextLine();
        
        System.out.print("Valor: ");
        double valor = scanner.nextDouble();
        scanner.nextLine();
        
        System.out.print("Data de vencimento (AAAA-MM-DD): ");
        LocalDate dataVencimento = LocalDate.parse(scanner.nextLine());
        
        // Listar tipos disponíveis
        System.out.println("\nTipos de despesa disponíveis:");
        List<TipoDespesa> tipos = tipoDespesaService.listarTiposDespesa();
        for (int i = 0; i < tipos.size(); i++) {
            System.out.println((i + 1) + ". " + tipos.get(i).getNome());
        }
        System.out.print("Escolha o tipo (número): ");
        int tipoIndex = scanner.nextInt() - 1;
        scanner.nextLine();
        
        if (tipoIndex < 0 || tipoIndex >= tipos.size()) {
            System.out.println("Tipo inválido!");
            return;
        }
        
        String tipoDespesa = tipos.get(tipoIndex).getNome();
        
        // Escolher categoria
        System.out.println("\nCategorias disponíveis:");
        System.out.println("1. Transporte");
        System.out.println("2. Alimentação");
        System.out.println("3. Eventual");
        System.out.println("4. Supérfluo");
        System.out.print("Escolha a categoria: ");
        int categoria = scanner.nextInt();
        scanner.nextLine();
        
        Despesa despesa = null;
        
        switch (categoria) {
            case 1:
                System.out.print("Meio de transporte: ");
                String meioTransporte = scanner.nextLine();
                System.out.print("Distância (km): ");
                double distancia = scanner.nextDouble();
                scanner.nextLine();
                despesa = new DespesaTransporte(descricao, valor, dataVencimento, tipoDespesa, usuarioLogado, meioTransporte, distancia);
                break;
            case 2:
                System.out.print("Estabelecimento: ");
                String estabelecimento = scanner.nextLine();
                System.out.print("Refeição completa? (s/n): ");
                boolean refeicaoCompleta = scanner.nextLine().equalsIgnoreCase("s");
                despesa = new DespesaAlimentacao(descricao, valor, dataVencimento, tipoDespesa, usuarioLogado, estabelecimento, refeicaoCompleta);
                break;
            case 3:
                System.out.print("Duração em dias: ");
                int duracaoDias = scanner.nextInt();
                scanner.nextLine();
                System.out.print("É recorrente? (s/n): ");
                boolean recorrente = scanner.nextLine().equalsIgnoreCase("s");
                despesa = new DespesaEventual(descricao, valor, dataVencimento, tipoDespesa, usuarioLogado, duracaoDias, recorrente);
                break;
            case 4:
                System.out.print("É essencial? (s/n): ");
                boolean essencial = scanner.nextLine().equalsIgnoreCase("s");
                System.out.print("Nível de prioridade (1-10): ");
                int nivelPrioridade = scanner.nextInt();
                scanner.nextLine();
                despesa = new DespesaSuperfluo(descricao, valor, dataVencimento, tipoDespesa, usuarioLogado, essencial, nivelPrioridade);
                break;
            default:
                System.out.println("Categoria inválida!");
                return;
        }
        
        despesaService.adicionarDespesa(despesa);
        System.out.println("Despesa cadastrada com sucesso!");
        System.out.println(despesa);
    }
    
    private static void anotarPagamento() {
        System.out.println("\n=== ANOTAR PAGAMENTO ===");
        
        List<Despesa> despesas = despesaService.listarTodasDespesas();
        if (despesas.isEmpty()) {
            System.out.println("Nenhuma despesa cadastrada!");
            return;
        }
        
        System.out.println("Despesas pendentes:");
        for (int i = 0; i < despesas.size(); i++) {
            Despesa despesa = despesas.get(i);
            if (!despesa.estaPaga()) {
                System.out.println((i + 1) + ". " + despesa);
            }
        }
        
        System.out.print("Escolha a despesa (número): ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine();
        
        if (index < 0 || index >= despesas.size()) {
            System.out.println("Despesa inválida!");
            return;
        }
        
        Despesa despesa = despesas.get(index);
        
        System.out.print("Data do pagamento (AAAA-MM-DD): ");
        LocalDate dataPagamento = LocalDate.parse(scanner.nextLine());
        
        System.out.print("Valor pago: ");
        double valorPago = scanner.nextDouble();
        scanner.nextLine();
        
        despesaService.registrarPagamento(despesa.getId(), dataPagamento, valorPago);
        System.out.println("Pagamento registrado com sucesso!");
    }
    
    private static void listarDespesasEmAberto() {
        System.out.println("\n=== DESPESAS EM ABERTO ===");
        
        List<Despesa> despesas = despesaService.listarTodasDespesas();
        boolean encontrou = false;
        
        for (Despesa despesa : despesas) {
            if (!despesa.estaPaga()) {
                System.out.println(despesa);
                encontrou = true;
            }
        }
        
        if (!encontrou) {
            System.out.println("Nenhuma despesa em aberto!");
        }
    }
    
    private static void listarDespesasPagas() {
        System.out.println("\n=== DESPESAS PAGAS ===");
        
        List<Despesa> despesas = despesaService.listarTodasDespesas();
        boolean encontrou = false;
        
        for (Despesa despesa : despesas) {
            if (despesa.estaPaga()) {
                System.out.println(despesa);
                encontrou = true;
            }
        }
        
        if (!encontrou) {
            System.out.println("Nenhuma despesa paga!");
        }
    }
    
    private static void gerenciarTiposDespesa() {
        while (true) {
            System.out.println("\n=== GERENCIAR TIPOS DE DESPESA ===");
            System.out.println("1. Listar tipos");
            System.out.println("2. Criar tipo");
            System.out.println("3. Editar tipo");
            System.out.println("4. Excluir tipo");
            System.out.println("5. Voltar");
            System.out.print("Escolha uma opção: ");
            
            int opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1:
                    listarTiposDespesa();
                    break;
                case 2:
                    criarTipoDespesa();
                    break;
                case 3:
                    editarTipoDespesa();
                    break;
                case 4:
                    excluirTipoDespesa();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }
    
    private static void listarTiposDespesa() {
        System.out.println("\n=== TIPOS DE DESPESA ===");
        List<TipoDespesa> tipos = tipoDespesaService.listarTiposDespesa();
        
        if (tipos.isEmpty()) {
            System.out.println("Nenhum tipo cadastrado!");
            return;
        }
        
        for (TipoDespesa tipo : tipos) {
            System.out.println(tipo);
        }
    }
    
    private static void criarTipoDespesa() {
        System.out.println("\n=== CRIAR TIPO DE DESPESA ===");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Descrição: ");
        String descricao = scanner.nextLine();
        
        tipoDespesaService.criarTipoDespesa(nome, descricao);
        System.out.println("Tipo criado com sucesso!");
    }
    
    private static void editarTipoDespesa() {
        // Implementação similar
        System.out.println("Funcionalidade em desenvolvimento...");
    }
    
    private static void excluirTipoDespesa() {
        // Implementação similar
        System.out.println("Funcionalidade em desenvolvimento...");
    }
    
    private static void gerenciarUsuarios() {
        while (true) {
            System.out.println("\n=== GERENCIAR USUÁRIOS ===");
            System.out.println("1. Listar usuários");
            System.out.println("2. Criar usuário");
            System.out.println("3. Editar usuário");
            System.out.println("4. Voltar");
            System.out.print("Escolha uma opção: ");
            
            int opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1:
                    listarUsuarios();
                    break;
                case 2:
                    criarUsuario();
                    break;
                case 3:
                    // editarUsuario();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }
    
    private static void listarUsuarios() {
        System.out.println("\n=== USUÁRIOS ===");
        List<Usuario> usuarios = usuarioService.listarUsuarios();
        
        for (Usuario usuario : usuarios) {
            System.out.println(usuario);
        }
    }
    
    private static void criarUsuario() {
        System.out.println("\n=== CRIAR USUÁRIO ===");
        System.out.print("Login: ");
        String login = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        
        if (usuarioService.cadastrarUsuario(login, senha, nome)) {
            System.out.println("Usuário criado com sucesso!");
        } else {
            System.out.println("Erro: Login já existe!");
        }
    }
}