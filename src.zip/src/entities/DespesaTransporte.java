package model;

import java.time.LocalDate;

public class DespesaTransporte extends Despesa {
    private String meioTransporte;
    private double distancia;
    
    public DespesaTransporte(String descricao, double valor, LocalDate dataVencimento, 
                           String tipoDespesa, String usuario, String meioTransporte, double distancia) {
        super(descricao, valor, dataVencimento, tipoDespesa, usuario);
        this.meioTransporte = meioTransporte;
        this.distancia = distancia;
    }
    
    // Construtor sobrecarregado para carregar do arquivo
    public DespesaTransporte(String id, String descricao, double valor, LocalDate dataVencimento,
                           LocalDate dataPagamento, double valorPago, String tipoDespesa, 
                           String usuario, String meioTransporte, double distancia) {
        super(id, descricao, valor, dataVencimento, dataPagamento, valorPago, tipoDespesa, usuario);
        this.meioTransporte = meioTransporte;
        this.distancia = distancia;
    }
    
    @Override
    public String getCategoria() {
        return "TRANSPORTE";
    }
    
    @Override
    public double calcularValorComImposto() {
        // Transporte tem 12% de imposto
        return valor * 1.12;
    }
    
    // Sobrescrita do método toString
    @Override
    public String toString() {
        return super.toString() + String.format(" | Meio: %s | Distância: %.1f km", meioTransporte, distancia);
    }
    
    public String getMeioTransporte() { return meioTransporte; }
    public double getDistancia() { return distancia; }
}