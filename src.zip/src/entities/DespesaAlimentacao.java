package model;

import java.time.LocalDate;

public class DespesaAlimentacao extends Despesa {
    private String estabelecimento;
    private boolean refeicaoCompleta;
    
    public DespesaAlimentacao(String descricao, double valor, LocalDate dataVencimento,
                            String tipoDespesa, String usuario, String estabelecimento, boolean refeicaoCompleta) {
        super(descricao, valor, dataVencimento, tipoDespesa, usuario);
        this.estabelecimento = estabelecimento;
        this.refeicaoCompleta = refeicaoCompleta;
    }
    
    public DespesaAlimentacao(String id, String descricao, double valor, LocalDate dataVencimento,
                            LocalDate dataPagamento, double valorPago, String tipoDespesa,
                            String usuario, String estabelecimento, boolean refeicaoCompleta) {
        super(id, descricao, valor, dataVencimento, dataPagamento, valorPago, tipoDespesa, usuario);
        this.estabelecimento = estabelecimento;
        this.refeicaoCompleta = refeicaoCompleta;
    }
    
    @Override
    public String getCategoria() {
        return "ALIMENTAÇÃO";
    }
    
    @Override
    public double calcularValorComImposto() {
        // Alimentação tem 0% de imposto (isenção)
        return valor;
    }
    
    @Override
    public String toString() {
        return super.toString() + String.format(" | Estabelecimento: %s | Refeição Completa: %s",
                                               estabelecimento, refeicaoCompleta ? "Sim" : "Não");
    }
    
    public String getEstabelecimento() { return estabelecimento; }
    public boolean isRefeicaoCompleta() { return refeicaoCompleta; }
}