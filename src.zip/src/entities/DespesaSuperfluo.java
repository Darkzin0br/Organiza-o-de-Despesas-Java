package model;

import java.time.LocalDate;

public class DespesaSuperfluo extends Despesa {
    private boolean essencial;
    private int nivelPrioridade;
    
    public DespesaSuperfluo(String descricao, double valor, LocalDate dataVencimento,
                           String tipoDespesa, String usuario, boolean essencial, int nivelPrioridade) {
        super(descricao, valor, dataVencimento, tipoDespesa, usuario);
        this.essencial = essencial;
        this.nivelPrioridade = nivelPrioridade;
    }
    
    public DespesaSuperfluo(String id, String descricao, double valor, LocalDate dataVencimento,
                           LocalDate dataPagamento, double valorPago, String tipoDespesa,
                           String usuario, boolean essencial, int nivelPrioridade) {
        super(id, descricao, valor, dataVencimento, dataPagamento, valorPago, tipoDespesa, usuario);
        this.essencial = essencial;
        this.nivelPrioridade = nivelPrioridade;
    }
    
    @Override
    public String getCategoria() {
        return "SUPERFLUO";
    }
    
    @Override
    public double calcularValorComImposto() {
        // Supérfluo tem 25% de imposto
        return valor * 1.25;
    }
    
    @Override
    public String toString() {
        return super.toString() + String.format(" | Essencial: %s | Prioridade: %d",
                                               essencial ? "Sim" : "Não", nivelPrioridade);
    }
    
    public boolean isEssencial() { return essencial; }
    public int getNivelPrioridade() { return nivelPrioridade; }
}