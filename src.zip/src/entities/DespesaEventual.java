package model;

import java.time.LocalDate;

public class DespesaEventual extends Despesa {
    private int duracaoDias;
    private boolean recorrente;
    
    public DespesaEventual(String descricao, double valor, LocalDate dataVencimento,
                          String tipoDespesa, String usuario, int duracaoDias, boolean recorrente) {
        super(descricao, valor, dataVencimento, tipoDespesa, usuario);
        this.duracaoDias = duracaoDias;
        this.recorrente = recorrente;
    }
    
    public DespesaEventual(String id, String descricao, double valor, LocalDate dataVencimento,
                          LocalDate dataPagamento, double valorPago, String tipoDespesa,
                          String usuario, int duracaoDias, boolean recorrente) {
        super(id, descricao, valor, dataVencimento, dataPagamento, valorPago, tipoDespesa, usuario);
        this.duracaoDias = duracaoDias;
        this.recorrente = recorrente;
    }
    
    @Override
    public String getCategoria() {
        return "EVENTUAL";
    }
    
    @Override
    public double calcularValorComImposto() {
        // Eventual tem 15% de imposto
        return valor * 1.15;
    }
    
    @Override
    public String toString() {
        return super.toString() + String.format(" | Duração: %d dias | Recorrente: %s",
                                               duracaoDias, recorrente ? "Sim" : "Não");
    }
    
    public int getDuracaoDias() { return duracaoDias; }
    public boolean isRecorrente() { return recorrente; }
}