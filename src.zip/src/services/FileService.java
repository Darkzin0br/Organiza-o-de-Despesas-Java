package services;

import java.util.List;

public class FileService {

    public static void salvarDados(String arquivoUsuarios, List<String> linhas) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'salvarDados'");
    }

}
