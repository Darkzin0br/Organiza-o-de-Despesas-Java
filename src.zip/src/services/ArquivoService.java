package services;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArquivoService {
    
    public static void salvarDados(String arquivo, List<String> dados) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(arquivo))) {
            for (String linha : dados) {
                writer.write(linha);
                writer.newLine();
            }
        }
    }
    
    public static List<String> carregarDados(String arquivo) throws IOException {
        List<String> dados = new ArrayList<>();
        File file = new File(arquivo);
        if (!file.exists()) {
            return dados;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                if (!linha.trim().isEmpty()) {
                    dados.add(linha);
                }
            }
        }
        return dados;
    }
}