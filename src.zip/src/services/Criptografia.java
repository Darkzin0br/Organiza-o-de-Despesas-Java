package services;

public class Criptografia {

    public static String criptografarSenha(String novaSenha) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'criptografarSenha'");
    }

    public static boolean verificarSenha(String senha, String senha2) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'verificarSenha'");
    }

}
