package services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import entities.Usuario;

public class GerenciadorUsuarios {
    private List<Usuario> usuarios;
    private static final String ARQUIVO_USUARIOS = "data/usuarios.txt";
    
    public GerenciadorUsuarios() {
        this.usuarios = new ArrayList<>();
        carregarUsuarios();
    }
    
    public boolean cadastrarUsuario(String login, String senha, String nome) {
        if (buscarUsuarioPorLogin(login) != null) {
            return false; // Usuário já existe
        }
        
        String senhaCriptografada = Criptografia.criptografarSenha(senha);
        Usuario usuario = new Usuario(login, senhaCriptografada, nome);
        usuarios.add(usuario);
        salvarUsuarios();
        return true;
    }
    
    public boolean editarUsuario(String login, String novoNome, String novaSenha) {
        Usuario usuario = buscarUsuarioPorLogin(login);
        if (usuario != null) {
            usuario.setNome(novoNome);
            if (novaSenha != null && !novaSenha.trim().isEmpty()) {
                String senhaCriptografada = Criptografia.criptografarSenha(novaSenha);
                usuario.setSenha(senhaCriptografada);
            }
            salvarUsuarios();
            return true;
        }
        return false;
    }
    
    public List<Usuario> listarUsuarios() {
        return new ArrayList<>(usuarios);
    }
    
    public Usuario buscarUsuarioPorLogin(String login) {
        return usuarios.stream()
                .filter(u -> u.getLogin().equals(login))
                .findFirst()
                .orElse(null);
    }
    
    public boolean autenticarUsuario(String login, String senha) {
        Usuario usuario = buscarUsuarioPorLogin(login);
        if (usuario != null) {
            return Criptografia.verificarSenha(senha, usuario.getSenha());
        }
        return false;
    }
    
    private void salvarUsuarios() {
        List<String> linhas = new ArrayList<>();
               for (Usuario usuario : usuarios) {
            linhas.add(usuario.getLogin() + "|" + usuario.getSenha() + "|" + usuario.getNome());
        }
        FileService.salvarDados(ARQUIVO_USUARIOS, linhas);
    }
    
    private void carregarUsuarios() {
        try {
            List<String> linhas = ArquivoService.carregarDados(ARQUIVO_USUARIOS);
            for (String linha : linhas) {
                String[] partes = linha.split("\\|");
                if (partes.length >= 3) {
                    Usuario usuario = new Usuario(partes[0], partes[1], partes[2]);
                    usuarios.add(usuario);
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar usuários: " + e.getMessage());
        }
    }
}