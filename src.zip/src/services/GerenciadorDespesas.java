package services;

import model.Despesa;
import entities.*;
import interfaces.Pagavel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GerenciadorDespesas {
    private List<Despesa> despesas;
    private static final String ARQUIVO_DESPESAS = "data/despesas.txt";
    
    public GerenciadorDespesas() {
        this.despesas = new ArrayList<>();
        carregarDespesas();
    }
    
    public void adicionarDespesa(Despesa despesa) {
        despesas.add(despesa);
        salvarDespesas();
    }
    
    public void registrarPagamento(String idDespesa, LocalDate dataPagamento, double valor) {
        Despesa despesa = buscarDespesaPorId(idDespesa);
        if (despesa != null) {
            // Usando polimorfismo através da interface Pagavel
            Pagavel pagavel = despesa;
            pagavel.registrarPagamento(dataPagamento, valor);
            salvarDespesas();
        }
    }
    
    public List<Despesa> listarDespesasAbertasPeriodo(LocalDate inicio, LocalDate fim) {
        return despesas.stream()
                .filter(d -> !d.estaPaga())
                .filter(d -> !d.getDataVencimento().isBefore(inicio) && !d.getDataVencimento().isAfter(fim))
                .collect(Collectors.toList());
    }
    
    public List<Despesa> listarDespesasPagasPeriodo(LocalDate inicio, LocalDate fim) {
        return despesas.stream()
                .filter(Despesa::estaPaga)
                .filter(d -> d.getDataPagamento() != null && 
                            !d.getDataPagamento().isBefore(inicio) && !d.getDataPagamento().isAfter(fim))
                .collect(Collectors.toList());
    }
    
    public List<Despesa> listarDespesasPorCategoria(String categoria) {
        return despesas.stream()
                .filter(d -> d.getCategoria().equalsIgnoreCase(categoria))
                .collect(Collectors.toList());
    }
    
    public List<Despesa> listarTodasDespesas() {
        return new ArrayList<>(despesas);
    }
    
    public Despesa buscarDespesaPorId(String id) {
        return despesas.stream()
                .filter(d -> d.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
    
    public boolean editarDespesa(String id, String novaDescricao, double novoValor, LocalDate novaDataVencimento) {
        Despesa despesa = buscarDespesaPorId(id);
        if (despesa != null) {
            despesa.setDescricao(novaDescricao);
            despesa.setValor(novoValor);
            despesa.setDataVencimento(novaDataVencimento);
            salvarDespesas();
            return true;
        }
        return false;
    }
    
    public boolean excluirDespesa(String id) {
        Despesa despesa = buscarDespesaPorId(id);
        if (despesa != null) {
            despesas.remove(despesa);
            salvarDespesas();
            return true;
        }
        return false;
    }
    
    private void salvarDespesas() {
        try {
            List<String> linhas = new ArrayList<>();
            for (Despesa despesa : despesas) {
                String linha = converterDespesaParaLinha(despesa);
                linhas.add(linha);
            }
            ArquivoService.salvarDados(ARQUIVO_DESPESAS, linhas);
        } catch (IOException e) {
            System.out.println("Erro ao salvar despesas: " + e.getMessage());
        }
    }
    
    private void carregarDespesas() {
        try {
            List<String> linhas = ArquivoService.carregarDados(ARQUIVO_DESPESAS);
            for (String linha : linhas) {
                Despesa despesa = converterLinhaParaDespesa(linha);
                if (despesa != null) {
                    despesas.add(despesa);
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar despesas: " + e.getMessage());
        }
    }
    
    private String converterDespesaParaLinha(Despesa despesa) {
        // Formato: categoria|id|descricao|valor|dataVencimento|dataPagamento|valorPago|tipoDespesa|usuario|atributosEspecificos
        StringBuilder sb = new StringBuilder();
        sb.append(despesa.getCategoria()).append("|");
        sb.append(despesa.getId()).append("|");
        sb.append(despesa.getDescricao()).append("|");
        sb.append(despesa.getValor()).append("|");
        sb.append(despesa.getDataVencimento()).append("|");
        sb.append(despesa.getDataPagamento() != null ? despesa.getDataPagamento() : "null").append("|");
        sb.append(despesa.getValorPago()).append("|");
        sb.append(despesa.getTipoDespesa()).append("|");
        sb.append(despesa.getUsuario()).append("|");
        
        // Atributos específicos por categoria
        if (despesa instanceof DespesaTransporte) {
            DespesaTransporte dt = (DespesaTransporte) despesa;
            sb.append(dt.getMeioTransporte()).append("|").append(dt.getDistancia());
        } else if (despesa instanceof DespesaAlimentacao) {
            DespesaAlimentacao da = (DespesaAlimentacao) despesa;
            sb.append(da.getEstabelecimento()).append("|").append(da.isRefeicaoCompleta());
        } else if (despesa instanceof DespesaEventual) {
            DespesaEventual de = (DespesaEventual) despesa;
            sb.append(de.getDuracaoDias()).append("|").append(de.isRecorrente());
        } else if (despesa instanceof DespesaSuperfluo) {
            DespesaSuperfluo ds = (DespesaSuperfluo) despesa;
            sb.append(ds.isEssencial()).append("|").append(ds.getNivelPrioridade());
        }
        
        return sb.toString();
    }
    
    private Despesa converterLinhaParaDespesa(String linha) {
        String[] partes = linha.split("\\|");
        if (partes.length < 9) return null;
        
        String categoria = partes[0];
        String id = partes[1];
        String descricao = partes[2];
        double valor = Double.parseDouble(partes[3]);
        LocalDate dataVencimento = LocalDate.parse(partes[4]);
        LocalDate dataPagamento = partes[5].equals("null") ? null : LocalDate.parse(partes[5]);
        double valorPago = Double.parseDouble(partes[6]);
        String tipoDespesa = partes[7];
        String usuario = partes[8];
        
        switch (categoria) {
            case "TRANSPORTE":
                if (partes.length >= 11) {
                    String meioTransporte = partes[9];
                    double distancia = Double.parseDouble(partes[10]);
                    return new DespesaTransporte(id, descricao, valor, dataVencimento, dataPagamento, 
                                               valorPago, tipoDespesa, usuario, meioTransporte, distancia);
                }
                break;
                
            case "ALIMENTAÇÃO":
                if (partes.length >= 11) {
                    String estabelecimento = partes[9];
                    boolean refeicaoCompleta = Boolean.parseBoolean(partes[10]);
                    return new DespesaAlimentacao(id, descricao, valor, dataVencimento, dataPagamento,
                                                valorPago, tipoDespesa, usuario, estabelecimento, refeicaoCompleta);
                }
                break;
                
            case "EVENTUAL":
                if (partes.length >= 11) {
                    int duracaoDias = Integer.parseInt(partes[9]);
                    boolean recorrente = Boolean.parseBoolean(partes[10]);
                    return new DespesaEventual(id, descricao, valor, dataVencimento, dataPagamento,
                                             valorPago, tipoDespesa, usuario, duracaoDias, recorrente);
                }
                break;
                
            case "SUPERFLUO":
                if (partes.length >= 11) {
                    boolean essencial = Boolean.parseBoolean(partes[9]);
                    int nivelPrioridade = Integer.parseInt(partes[10]);
                    return new DespesaSuperfluo(id, descricao, valor, dataVencimento, dataPagamento,
                                              valorPago, tipoDespesa, usuario, essencial, nivelPrioridade);
                }
                break;
        }
        
        return null;
    }
}