package services;

import entities.TipoDespesa;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class GerenciadorTiposDespesa {
    private List<TipoDespesa> tiposDespesa;
    private static final String ARQUIVO_TIPOS_DESPESA = "data/tipos_despesa.txt";
    
    public GerenciadorTiposDespesa() {
        this.tiposDespesa = new ArrayList<>();
        carregarTiposDespesa();
    }
    
    public void criarTipoDespesa(String nome, String descricao) {
        String id = UUID.randomUUID().toString();
        TipoDespesa tipo = new TipoDespesa(id, nome, descricao);
        tiposDespesa.add(tipo);
        salvarTiposDespesa();
    }
    
    public boolean editarTipoDespesa(String id, String novoNome, String novaDescricao) {
        TipoDespesa tipo = buscarTipoDespesaPorId(id);
        if (tipo != null) {
            tipo.setNome(novoNome);
            tipo.setDescricao(novaDescricao);
            salvarTiposDespesa();
            return true;
        }
        return false;
    }
    
    public List<TipoDespesa> listarTiposDespesa() {
        return new ArrayList<>(tiposDespesa);
    }
    
    public boolean excluirTipoDespesa(String id) {
        TipoDespesa tipo = buscarTipoDespesaPorId(id);
        if (tipo != null) {
            tiposDespesa.remove(tipo);
            salvarTiposDespesa();
            return true;
        }
        return false;
    }
    
    public TipoDespesa buscarTipoDespesaPorId(String id) {
        return tiposDespesa.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
    
    public TipoDespesa buscarTipoDespesaPorNome(String nome) {
        return tiposDespesa.stream()
                .filter(t -> t.getNome().equalsIgnoreCase(nome))
                .findFirst()
                .orElse(null);
    }
    
    private void salvarTiposDespesa() {
        try {
            List<String> linhas = tiposDespesa.stream()
                    .map(t -> t.getId() + "|" + t.getNome() + "|" + t.getDescricao())
                    .collect(Collectors.toList());
            ArquivoService.salvarDados(ARQUIVO_TIPOS_DESPESA, linhas);
        } catch (IOException e) {
            System.out.println("Erro ao salvar tipos de despesa: " + e.getMessage());
        }
    }
    
    private void carregarTiposDespesa() {
        try {
            List<String> linhas = ArquivoService.carregarDados(ARQUIVO_TIPOS_DESPESA);
            for (String linha : linhas) {
                String[] partes = linha.split("\\|");
                if (partes.length >= 3) {
                    TipoDespesa tipo = new TipoDespesa(partes[0], partes[1], partes[2]);
                    tiposDespesa.add(tipo);
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar tipos de despesa: " + e.getMessage());
        }
    }
}