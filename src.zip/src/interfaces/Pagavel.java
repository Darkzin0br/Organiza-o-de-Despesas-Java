package interfaces;

import java.time.LocalDate;

public interface Pagavel {
    void registrarPagamento(LocalDate dataPagamento, double valor);
    boolean estaPaga();
    double getValorPendente();
}