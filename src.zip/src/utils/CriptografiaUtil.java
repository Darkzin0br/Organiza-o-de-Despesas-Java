package utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class CriptografiaUtil {
    
    public static String criptografarSenha(String senha) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(senha.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            // Fallback para desenvolvimento
            System.out.println("AVISO: Usando criptografia básica para desenvolvimento");
            return Base64.getEncoder().encodeToString(senha.getBytes());
        }
    }
    
    public static boolean verificarSenha(String senha, String senhaCriptografada) {
        return criptografarSenha(senha).equals(senhaCriptografada);
    }
}