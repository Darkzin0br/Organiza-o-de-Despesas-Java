package model;

import interfaces.Pagavel;
import java.time.LocalDate;
import java.util.UUID;

public abstract class Despesa implements Pagavel {
    protected String id;
    protected String descricao;
    protected double valor;
    protected LocalDate dataVencimento;
    protected LocalDate dataPagamento;
    protected double valorPago;
    protected String tipoDespesa;
    protected String usuario;
    
    // Contador estático global
    protected static int totalDespesas = 0;
    
    // Construtor sobrecarregado 1 - mínimo necessário
    public Despesa(String descricao, double valor, LocalDate dataVencimento, String tipoDespesa, String usuario) {
        this.id = UUID.randomUUID().toString();
        this.descricao = descricao;
        this.valor = valor;
        this.dataVencimento = dataVencimento;
        this.tipoDespesa = tipoDespesa;
        this.usuario = usuario;
        this.valorPago = 0.0;
        this.dataPagamento = null;
        totalDespesas++;
    }
    
    // Construtor sobrecarregado 2 - com todos os parâmetros
    public Despesa(String id, String descricao, double valor, LocalDate dataVencimento, 
                   LocalDate dataPagamento, double valorPago, String tipoDespesa, String usuario) {
        this.id = id;
        this.descricao = descricao;
        this.valor = valor;
        this.dataVencimento = dataVencimento;
        this.dataPagamento = dataPagamento;
        this.valorPago = valorPago;
        this.tipoDespesa = tipoDespesa;
        this.usuario = usuario;
        totalDespesas++;
    }
    
    // Implementação da interface Pagavel
    @Override
    public void registrarPagamento(LocalDate dataPagamento, double valor) {
        this.dataPagamento = dataPagamento;
        this.valorPago = valor;
    }
    
    @Override
    public boolean estaPaga() {
        return dataPagamento != null && valorPago >= valor;
    }
    
    @Override
    public double getValorPendente() {
        return valor - valorPago;
    }
    
    // Métodos abstratos que as subclasses devem implementar
    public abstract String getCategoria();
    public abstract double calcularValorComImposto();
    
    // Getters e Setters
    public String getId() { return id; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }
    public LocalDate getDataVencimento() { return dataVencimento; }
    public void setDataVencimento(LocalDate dataVencimento) { this.dataVencimento = dataVencimento; }
    public LocalDate getDataPagamento() { return dataPagamento; }
    public double getValorPago() { return valorPago; }
    public String getTipoDespesa() { return tipoDespesa; }
    public void setTipoDespesa(String tipoDespesa) { this.tipoDespesa = tipoDespesa; }
    public String getUsuario() { return usuario; }
    
    // Método estático
    public static int getTotalDespesas() {
        return totalDespesas;
    }
    
    @Override
    public String toString() {
        return String.format("ID: %s | Descrição: %s | Valor: R$ %.2f | Vencimento: %s | " +
                           "Status: %s | Categoria: %s | Tipo: %s",
                           id, descricao, valor, dataVencimento,
                           estaPaga() ? "Paga" : "Pendente", getCategoria(), tipoDespesa);
    }
}